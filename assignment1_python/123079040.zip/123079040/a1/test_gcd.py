#!/bin/python
from gcd import gcd

def test_gcd():
    assert gcd(600,400) == 200
    assert gcd(98,-67) == 1


